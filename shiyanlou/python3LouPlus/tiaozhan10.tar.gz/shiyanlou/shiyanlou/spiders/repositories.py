# -*- coding: utf-8 -*-
import scrapy
from shiyanlou.items import RepositoriesItem

class RepositoriesSpider(scrapy.Spider):
    name = 'repositories'
    #allowed_domains = ['shiyanlou.com']
    #start_urls = ['']

    @property
    def start_urls(self):
        return [
        "https://github.com/shiyanlou?before=Y3Vyc29yOnYyOpK5MjAxNy0wNi0wN1QwNjoyMToxMCswODowMM4FkpVn&tab=repositories",
        "https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK5MjAxNy0wNi0wN1QwNjoyMToxNiswODowMM4FkpXb&tab=repositories",
        "https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK5MjAxNS0wMS0yNlQxNjoxNzo1MyswODowMM4Bx3_0&tab=repositories",
        "https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK5MjAxNC0xMS0yNFQxNTowMDoxNyswODowMM4BnPdj&tab=repositories"
        ]

    def parse(self, response):
        for one in response.xpath('//div[@class="col-9 d-inline-block"]'):
            item=RepositoriesItem({
                'name':one.xpath('.//h3/a/text()').extract_first().strip(),
                'update_time':one.xpath('.//relative-time/@datetime').extract_first()
            })
            yield item
